function texpander_start()
{
    $('.texpander-container').click(function (e)
    {                   
        e.stopPropagation();
    });
}