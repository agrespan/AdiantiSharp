function tmenubar_start()
{
    $(document).ready( function() {
        $('.dropdown-toggle').dropdown()
    });
}